import sys
import pickle
sys.path.append('./library')

from Utility import *
from EnumIndexBuilder import *

[param, mass] = readParam('parameter.txt')
specdict = readSpectra(param['msdata'], param, mass)
pickle.dump(specdict, file('spectra.pickle', 'w'))

specdict = pickle.load(file('spectra.pickle'))
deisotoped = dict()
titles = specdict.keys()
for i in range(len(titles)):
	title = titles[i]
	(one, align) = specdict[title].deisotope(mass, 4, 0.02)
	deisotoped[title] = one
pickle.dump(deisotoped, file('deisotoped.pickle', 'w'))
deisotoped = pickle.load(file('deisotoped.pickle'))
specdict = deisotoped
index = EnumIndexBuilder('ecoli_riboprot_fwdanddec.fasta', specdict, mass, param)

del index.param['database']

del index.param['msdata']

del index.param['fix_mod_mass']

del index.param['fix_mod_res']

pickle.dump(index, file('index.pickle', 'w'))
index = pickle.load(file('index.pickle')) 

results = []
titles = []
for title in index.searchIndex.keys():
        if len(index.searchIndex[title]) != 0:
                titles.append(title)

length = len(titles)
for i in range(0, length):
        print i
        sys.stdout.flush()
        title = titles[i]
        result = getMatchesPerSpectrum(mass, param, index, title)
        result = (title, result)
        results.append(result)

pickle.dump(results, file('results.pickle', 'w'))
results = pickle.load(file('results.pickle'))

tophits = getTophits(index, results)

pickle.dump(tophits, file('tophits.pickle', 'w'))
